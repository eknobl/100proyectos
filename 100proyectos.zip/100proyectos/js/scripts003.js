
// VARIABLES

const animation = document.querySelector(".linea");
const hex = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"];
let linea = document.querySelectorAll(".linea"); 

// JS UTILIZA EL NÚMERO AL AZAR Y LO CONVIERTE EN UN COLOR
animation.addEventListener("animationiteration", function() {
  let hexColor = "#";
  for (let i = 0; i < 6; i++ ) {  
        hexColor += hex[getRandomNumber()];
        for (let ii = 0; ii < 6; ii++ ) {
        linea[ii].style.stroke = hexColor;
        };
 };
});

// FUNCIÓN PARA OBTENER NÚMERO AL AZAR
function getRandomNumber() {
    return Math.floor(Math.random() * hex.length)
}



//let secretNumber = Math.trunc(Math.random() * 20) +1;