

// Variables
const hex = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"]; // The array with the components for the hex color
let circulo = document.querySelector("circulo"); // Targets the btn id in html and transforms it into a js variable 
let color = document.querySelector(".color"); // Targets the span text in html and trasforms it into a js variable  





btn.addEventListener("click", function() {
    let hexColor = "#"; // En esta variable se van a agregar los 6 valores de un color hex al azar
    for (let i = 0; i < 6; i++ ) {  
        hexColor += hex[getRandomNumber()]; // Loop para conseguir 6 valores al azar
    
      color.textContent = hexColor; // Liga hexColor al valor de color en CSS
      document.querySelector(".circulo1").style.backgroundColor = hexColor;
      document.querySelector(".circulo2").style.backgroundColor = hexColor;
      document.querySelector(".circulo3").style.backgroundColor = hexColor;
      document.querySelector(".circulo4").style.backgroundColor = hexColor;
      document.querySelector(".circulo5").style.backgroundColor = hexColor;
      document.querySelector(".btn-hex").style.backgroundColor = hexColor;
  
  };
  
})




function getRandomNumber() {
    return Math.floor(Math.random() * hex.length)
}




